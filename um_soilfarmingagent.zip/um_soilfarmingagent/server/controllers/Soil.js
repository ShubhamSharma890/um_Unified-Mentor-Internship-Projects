import SoilModel from "../models/Soil.js";

export const CreateSoil = async (req,res) => {
    try {
        const soilData=await SoilModel.create({
            name: req.body.name,
            image: req?.file?.filename,
        });
        if(soilData) res.status(201).send({message: "Soil Created"});
        else res.status(400).send({ message: "Unable to create please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const UpdateSoil = async (req,res) => {
    try {
        const soilData=await SoilModel.findByIdAndUpdate(
            { _id: req.body.id},
            {
            name: req.body.name,
            image: req?.file?.filename,
        });
        if(soilData) res.status(201).send({message: "Soil Updated"});
        else res.status(400).send({ message: "Unable to update please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const DeleteSoil = async (req,res) => {
    try {
        const soilData=await SoilModel.deleteOne(
            { _id: req.body.id});
        if(soilData.deletedCount ==1) res.status(201).send({message: "Soil Deleted!!!"});
        else res.status(400).send({ message: "Unable to delete please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const GetSoils = async (req,res) => {
    try {
        const soilData = await SoilModel.find();
        res.status(200).send({ soilData });
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};
