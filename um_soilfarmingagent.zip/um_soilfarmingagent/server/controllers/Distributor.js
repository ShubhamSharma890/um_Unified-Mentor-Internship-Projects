import DistributorModel from "../models/Distributor.js";

export const CreateDistributor = async(req,res)=>{
    try {
        let images = req?.files?.map((item) => {
            return item.filename;
        });
        const distributorData = await DistributorModel.create({
            name: req.body.name,
            description: req.body.description,
            qty: req.body.qty,
            price: req.body.price,
            images: images,
            crop: req.body.cropId,
        });
        if(distributorData) res.status(201).send({message: "Distributor Created"});
        else res.status(404).send({message: "unable to create Distributor please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const UpdateDistributor = async(req,res)=>{
    try {
        let images = req?.files?.map((item) => {
            return item.filename;
        });
        const distributorData = await DistributorModel.findByIdAndUpdate(
            {_id: req.body.id},
        {
            name: req.body.name,
            description: req.body.description,
            qty: req.body.qty,
            price: req.body.price,
            images: images,
            crop: req.body.cropId,
        });
        if(distributorData) res.status(201).send({message: "Distributor Updated"});
        else res.status(404).send({message: "unable to update Distributor please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const DeleteDistributor = async (req,res) => {
    try {
        const distributorData=await DistributorModel.deleteOne(
            { _id: req.body.id});
        if(distributorData.deletedCount ==1) res.status(200).send({message: "Distributor Deleted!!!"});
        else res.status(400).send({ message: "Unable to delete Distributor please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const GetDistributorsByCropId = async (req,res) => {
    try {
        const distributorData = await DistributorModel.find({
            crop: req.query.cropId,
        }).populate({path: "crop",populate: [{path:"soil"}] });
        res.status(200).send({ distributorData });
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const GetDistributorDetails = async (req,res) => {
    try{
        const distributorData = await DistributorModel.findOne({
            _id: req.query.id,
        }).populate({path: "crop", populate: [{path: "soil"}]});
    } catch(e){
        res.status(404).send({error: e?.message});
    }
};

export const UpdateDistributorQty = async (req,res) => {
    try {
        let distributorInDb = await DistributorModel.findOne({_id: req.body.id});
        let active = true;
        if(distributorInDb.qty - req?.body?.qty <=0) active=false;

        let distributorData = await DistributorModel.findByIdAndUpdate(
            {_id: req.body.id},
            {
                active:active,
                qty:distributorInDb.qty - req.body.qty,
            }
        );
        if (distributorInDb) res.status(200).send({ message: "Distributor's crop quantity updated"});
        else res.status(404).send({ message: "Unable to update Distributor quantity"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};
