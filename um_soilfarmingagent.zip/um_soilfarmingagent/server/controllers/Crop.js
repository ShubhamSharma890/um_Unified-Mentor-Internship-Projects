import CropModel from "../models/Crop.js";

export const CreateCrop = async (req,res) => {
    try {
        const cropData=await CropModel.create({
            name: req.body.name,
            image: req?.file?.filename,
            soil: req.body.soilId,
        });
        if(cropData) res.status(201).send({message: "Crop Created"});
        else res.status(400).send({ message: "Unable to create Crop please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const UpdateCrop = async (req,res) => {
    try {
        const cropData=await CropModel.findByIdAndUpdate(
            {
                _id: req.body.id,},
                {
            name: req.body.name,
            image: req?.file?.filename,
            soil: req.body.soilId,
        });
        if(cropData) res.status(201).send({message: "Crop Updated"});
        else res.status(400).send({ message: "Unable to update Crop please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const DeleteCrop = async (req,res) => {
    try {
        const soilData=await CropModel.deleteOne(
            { _id: req.body.id});
        if(cropData.deletedCount ==1) res.status(201).send({message: "Crop Deleted!!!"});
        else res.status(400).send({ message: "Unable to delete please check controller"});
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};

export const GetCropsBySoilId = async (req,res) => {
    try {
        const cropData = await CropModel.find({
            soil: req.query.soilId,
        }).populate("soil");
        res.status(200).send({ cropData });
    } catch (e) {
        res.status(404).send({error: e?.message});
    }
};
