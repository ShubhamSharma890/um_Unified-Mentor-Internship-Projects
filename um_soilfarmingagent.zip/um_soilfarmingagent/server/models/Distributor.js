import mongoose from "mongoose";

const DistributorSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        description: {
            type: String,
            required: true,
        },
        qty: {
            type: Number,
            required: true,
        }, //quantity
        price: {
            type: Number,
            required: true,
        },
        images: {
            type: [String],
            required: true,
        },
        crop: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "crop",
            required: true,
        },
    },
    {timestamps: true}
);

const DistributorModel = mongoose.model("distributor", DistributorSchema);
export default DistributorModel;
