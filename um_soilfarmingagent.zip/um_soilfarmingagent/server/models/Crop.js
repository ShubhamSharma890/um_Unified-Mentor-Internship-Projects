import mongoose from "mongoose";

const CropSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        image: {
            type: String,
            required: true,
        },
        soil: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "soil",
            required: true,
        },
    },
    {timestamps: true}
);

const CropModel = mongoose.model("crop",CropSchema);
export default CropModel;
