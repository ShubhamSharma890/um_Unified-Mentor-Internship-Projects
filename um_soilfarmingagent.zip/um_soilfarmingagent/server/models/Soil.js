import mongoose from "mongoose";

const SoilSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        image: {
            type: String,
            required: true,
        },
    },
    {timestamps: true}
);

const SoilModel = mongoose.model("soil",SoilSchema);
export default SoilModel;
