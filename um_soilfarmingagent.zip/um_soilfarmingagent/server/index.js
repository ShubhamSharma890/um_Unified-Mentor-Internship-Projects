import mongoose from "mongoose";
import dotenv from "dotenv";
import express from "express";
import cors from "cors";
import multer from "multer";
import { CreateSoil, DeleteSoil, GetSoils, UpdateSoil } from "./controllers/Soil.js";
import { CreateCrop, DeleteCrop, GetCropsBySoilId, UpdateCrop } from "./controllers/Crop.js";
import { CreateDistributor, DeleteDistributor, GetDistributorDetails, GetDistributorsByCropId, UpdateDistributor, UpdateDistributorQty } from "./controllers/Distributor.js";
import { Login, Register } from './controllers/User.js'


dotenv.config();
const app=express();
app.use(cors());
app.use(express.json());

//Soil Module
const storageSoil = multer.diskStorage({
    destination: "uploadsSoil/",
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}--${file.originalname}`);
    },
});
const uploadsSoil = multer({
    storage: storageSoil,
});

// http://localhost:7001/soil

// APIs
app.post("/soil", uploadsSoil.single("image"), CreateSoil);
app.put("/soil", uploadsSoil.single("image"),UpdateSoil);
app.delete("/soil", DeleteSoil);
app.get("/soil", GetSoils);

// Crop Module
const storageDep = multer.diskStorage({
    destination: "uploadsCrop/",
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}--${file.originalname}`);
    },
});
const uploadsCrop = multer({
    storage: storageDep,
});

// http://localhost:7001/crop

// APIs
app.post("/crop", uploadsCrop.single("image"), CreateCrop);
app.put("/crop", uploadsCrop.single("image"),UpdateCrop);
app.delete("/crop", DeleteCrop);
app.get("/crop", GetCropsBySoilId);

// Distributor Module
const storageDistributor = multer.diskStorage({
    destination: "uploadsDistributor/",
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}--${file.originalname}`);
    },
});
const uploadsDistributor = multer({
    storage: storageDistributor,
});

// http://localhost:7001/distributor

//APIs
app.post("/distributor",uploadsDistributor.array("images"), CreateDistributor);
app.put("/distributor",uploadsDistributor.array("images"), UpdateDistributor);
app.delete("/distributor", DeleteDistributor);
app.get("/distributor", GetDistributorsByCropId);
app.get("/distributorDetails", GetDistributorDetails);
app.put("/updateDistributorQty", UpdateDistributorQty);

//User module
// http://localhost:7001/register
app.post("/register", Register); 
// http://localhost:7001/login
app.post("/login", Login); 

//Image Access
app.use(express.static("uploadsSoil/"));
app.use(express.static("uploadsCrop/"));
app.use(express.static("uploadsDistributor/"));


mongoose.connect(process.env.DB_URL).then((d)=>{
    console.log("database connected successfully");
    app.listen(process.env.PORT, ()=>{
        console.log("Server running at PORT : " + [process.env.PORT]);
    })
})
.catch((e)=>{
    console.log("database connection error");
});
