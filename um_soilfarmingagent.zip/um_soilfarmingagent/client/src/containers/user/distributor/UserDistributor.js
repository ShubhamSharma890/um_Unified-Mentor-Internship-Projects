import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import {useLocation, useNavigate} from "react-router-dom"
import axios from "axios"
import ROUTES from '../../../navigations/Routes';

function useQuery(){
  const {search} = useLocation();
  return React.useMemo(()=> new URLSearchParams(search), [search]);
}

function UserDistributor() {
  const[distributors, setDistributors] = useState(null);
  const navigate = useNavigate();
  const queryParam = useQuery();

  useEffect(() => { getAll();},[]);

  function getAll(){
    try {
      axios.get("http://localhost:7001/distributor?cropId=" + queryParam.get("id")
    ).then((d) => {setDistributors(d.data.distributorData);
    });
    } catch (error) {
      console.log('Fail to submit data!!!');
    }
  }

  function renderDistributors(){
    return distributors?.map((item) => {
      return(
        <div className='col-3'>
          <div className='card'>
            <img className='card-img-top'
            src={"http://localhost:7001/" + item.images[0]}
            alt='Card image cap'
            />
            <div className='card-body'>
              <h5 className='card-title'>{item.name}</h5>
              <h5 className='card-title'>{item.price}</h5>
              <h5 className='card-title'>{item.description}</h5>
              <a onClick={() =>{navigate(ROUTES.distributorDetail.name + 
                "?id=" + 
                queryParam.get("id")
              );
              }} className='btn btn-primary text-white'>
                View Details
                </a>
            </div>
          </div>
        </div>
      )
    })
  }
  return (
    <div>
      <Header/>
      <h2 className='text-primary text-center'>{queryParam.get("name")}</h2>
      <div className='row m-4'>{renderDistributors()}</div>
      </div>
  );
}

export default UserDistributor;
