import React, { useEffect, useState } from 'react';
import Header from '../../../components/Header';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import ROUTES from '../../../navigations/Routes';

function Home() {

  const[soils, setSoils] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {getAll();}, []);

  function getAll(){
    try {
      axios
      .get("http://localhost:7001/soil")
      .then((d)=>{
        setSoils(d.data.soilData);
      });
    } catch (error) {
      console.log("Fail to submit data!!!");
    }
  }
  function renderSoils()
  {
    return soils?.map((item)=>{
      return(
        <div className='col-3'>
  <div className="card">
    <img 
      className="card-img-top" 
      src={`http://localhost:7001/${item.image}`}
      alt="Card image cap"
    />
    <div className="card-body">
      <h5 className="card-title">{item.name}</h5>
      <a 
        onClick={() => { navigate(`${ROUTES.crop.name}?id=${item._id}`); }} 
        className="btn btn-primary text-white"
      >
        View Crop
      </a>
    </div>
  </div>
</div>
      )
    })
  }
  return(
    <div>
      <Header />
      <div className='row m-2'>{renderSoils()}</div>
    </div>
  );
}

export default Home;
