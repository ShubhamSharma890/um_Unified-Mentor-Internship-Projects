import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import {useLocation, useNavigate} from "react-router-dom"
import axios from "axios"
import ROUTES from '../../../navigations/Routes';

function useQuery(){
  const {search} = useLocation();
  return React.useMemo(()=> new URLSearchParams(search), [search]);
}

function UserCrop() {

  const[crops, setCrops] = useState(null);
  const navigate = useNavigate();
  const queryParam = useQuery();

  useEffect(() => { getAll();},[]);

  function getAll(){
    try {
      axios.get("http://localhost:7001/crop?soilId=" + queryParam.get("id")
    ).then((d) => {setCrops(d.data.cropData);
    });
    } catch (error) {
      console.log('Fail to submit data!!!');
    }
  }
  function renderCrops(){
    return crops?.map((item) => {
      return(
        <div className='col-3'>
          <div className='card'>
            <img className='card-img-top'
            src={"http://localhost:7001/" + item.image}
            alt='Card image cap'
            />
            <div className='card-body'>
              <h5 className='card-title'>{item.name}</h5>
              <a onClick={() =>{navigate(ROUTES.distributor.name + 
                "?id=" + item._id +
                "&name=" +
                item.name
              );
              }} className='btn btn-primary text-white'>
                View Distributor
                </a>
            </div>
          </div>
        </div>
      )
    })
  }
  return (
    <div>
      <Header/>
      <h2 className='text-primary text-center'>{queryParam.get("name")}</h2>
      <div className='row m-4'>{renderCrops()}</div>
      </div>
  )
}

export default UserCrop;
