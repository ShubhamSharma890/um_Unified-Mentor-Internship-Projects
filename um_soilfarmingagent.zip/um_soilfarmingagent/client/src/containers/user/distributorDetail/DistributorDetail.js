import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import {useLocation, useNavigate} from "react-router-dom"
import axios from "axios"
import ROUTES from '../../../navigations/Routes';

function useQuery(){
  const {search} = useLocation();
  return React.useMemo(()=> new URLSearchParams(search), [search]);
}

function DistributorDetail() {
  const[distributorDetael, setDistributorDetael] = useState(null);
  const navigate = useNavigate();
  const queryParam = useQuery();


  useEffect(() => { getDistributorDetail();},[]);

  function getDistributorDetail(){
    try {
      axios.get("http://localhost:7001/distributorDetails?id=" + queryParam.get("id")
    ).then((d) => {setDistributorDetael(d.data.distributorData);
    });
    } catch (error) {
      console.log('Fail to submit data!!!');
    }
  }

  function renderImages(){
    return distributorDetael?.images?.map((item) => {
      return(
            <img className='card-img-top'
            src={"http://localhost:7001/" + item}
            height="150px"
            width="150px"
            />
      );
    });
  }
  return (
    <div>
      <Header/>
      <div className='row m-2 p-2'>
          <div className='card text-center mx-auto'>
            <div style={{ display: "flex", flexDirection: "row"}}>
              {renderImages()}
            </div>
            <div className='card-body'>
              Distributor
              <h5 className='card-title'>{distributorDetael?.name}</h5>
              description
              <h6 className='card-title'>{distributorDetael?.description}</h6>
              Total Items Left
              <h6 className='card-title'>{distributorDetael?.qty}</h6>
              Price:
              <h6 className='card-title'>{distributorDetael?.price}</h6>
              <a onClick={() =>{
                if(localStorage.getItem("id")) navigate(ROUTES.home.name);
                else navigate(ROUTES.login.name);
              }} 
              className='btn btn-primary'>
                Add To Cart
              </a>
            </div>
          </div>
        </div>
      </div>
  );
}
export default DistributorDetail;
