import React, { useState } from 'react';
import Header from '../../components/Header';
import {useNavigate} from "react-router-dom";
import axios from "axios";
import ROUTES from '../../navigations/Routes';


function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });


  const [formError, setFormError] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
  });


  const changeHandler = (e) => {
    setForm({...form, [e.target.name]: e.target.value});
  };


  function saveUser() {
    try {
      axios.post("http://localhost:7001/register", form).then((d) => {
        alert(d.data.message);
        navigate(ROUTES.login.name);
      }).catch((e) => {
        alert("Something went wrong!! Wrong user/password");
      });
    } catch (error) {
      console.log("Fail to submit data!!!!");
    }
  }
  function onRegisterSubmit(){
    let errors = false;
    let error = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    };
    if (form.firstName.trim().length ==0)
      {
      errors = true;
      error = {...error, firstName: "First Name Empty !!!"};
    }
    if (form.lastName.trim().length ==0){
      errors = true;
      error = {...error, lastName: "Last Name Empty !!!"};
    }
    if (form.email.trim().length ==0){
      errors = true;
      error = {...error, email: "Email Empty !!!"};
    }if (form.password.trim().length ==0){
      errors = true;
      error = {...error, password: "Password Empty !!!"};
    }if (form.confirmPassword.trim().length ==0){
      errors = true;
      error = {...error, confirmPassword: "Confirm Password Empty !!!"};
    }
    if (form.password != form.confirmPassword){
      errors = true;
      error = {...error, confirmPassword: "Password and confirm password must be same!!!",
      };
    }
    if (!(form.password.length >=6 && form.password.length <=12)){
      errors = true;
      error = {...error, confirmPassword: "Password length between 6 to 12 chars long!!!",
      };
    }
    if (errors){
      setFormError(error);
    } else {
      setFormError(error);
      saveUser();
    }
  }

  return (
    <div>
      <Header />
      <div className='row p-2 m-2'>
        <div className='card text-center mx-auto'>
          <div className='card-header bg-info text-white'>
            Register
            <div className='card-body'>
              <div className='form-group row'>
                <label className='col-sm-4'>First Name</label>
                <div className='col-sm-8'>
                  <input 
                  type="text"
                  name="firstName"
                  className='form-control'
                  placeholder='Enter First Name'
                  onChange={changeHandler}
                  value={form.firstName}
                  />
                  <p className='text-danger'>{formError.firstName}</p>
                </div>
                </div>

                <div className='form-group row'>
                <label className='col-sm-4'>Last Name</label>
                <div className='col-sm-8'>
                  <input 
                  type="text"
                  name="lastName"
                  className='form-control'
                  placeholder='Enter Last Name'
                  onChange={changeHandler}
                  value={form.lastName}
                  />
                  <p className='text-danger'>{formError.lastName}</p>
                </div>
                </div>
                
                <div className='form-group row'>
                <label className='col-sm-4'>Email</label>
                <div className='col-sm-8'>
                  <input 
                  type="text"
                  name="email"
                  className='form-control'
                  placeholder='Enter Email'
                  onChange={changeHandler}
                  value={form.email}
                  />
                  <p className='text-danger'>{formError.email}</p>
                </div>
                </div>
                
                <div className='form-group row'>
                <label className='col-sm-4'>Password</label>
                <div className='col-sm-8'>
                  <input 
                  type="password"
                  name="password"
                  className='form-control'
                  placeholder='Enter Password'
                  onChange={changeHandler}
                  value={form.password}
                  />
                  <p className='text-danger'>{formError.password}</p>
                </div>
                </div>
                
                <div className='form-group row'>
                <label className='col-sm-4'>Confirm Password</label>
                <div className='col-sm-8'>
                  <input 
                  type="password"
                  name="confirmPassword"
                  className='form-control'
                  placeholder='Enter Confirm Password'
                  onChange={changeHandler}
                  value={form.confirmPassword}
                  />
                  <p className='text-danger'>{formError.confirmPassword}</p>
                  </div>
                </div>
              </div>
              <div className='card-footer text-muted'>
                <button className='btn btn-success'
                onClick={() =>{onRegisterSubmit();}}
                >
                  Register
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}

export default Register;
