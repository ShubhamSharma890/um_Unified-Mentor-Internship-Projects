import { React } from "react";
import Header from "../../components/Header";

function Support() {
    return <div>
        <Header/>
        Support</div>;
}
export default Support;
