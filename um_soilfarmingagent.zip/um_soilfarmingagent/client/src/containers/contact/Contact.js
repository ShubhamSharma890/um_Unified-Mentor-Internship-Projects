import { React } from "react";
import Header from "../../components/Header";

function Contact() {
    return <div>
        <Header/>
        Contact
        </div>;
}
export default Contact;
