import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import {useLocation, useNavigate} from "react-router-dom"
import axios from "axios"
import ROUTES from '../../../navigations/Routes';

function useQuery(){
  const {search} = useLocation();
  return React.useMemo(()=> new URLSearchParams(search), [search]);
}

function Crop() {
  const queryParam = useQuery();
  const [cropId, setCropId] = useState(null);
  const [crops, setCrops] = useState(null);
  const [form, setForm] = useState({
    name : "",
    image: null,
    soilId: queryParam.get("id"),
  });
  const [formError, setFormError] = useState({
    name : "",
    image: "",
  });


  useEffect(() =>{
    getAll();
  }, []);

  const navigate = useNavigate();

  const changeHandler=(e) => {
    setForm({ ...form, [e.target.name] : e.target.value});
  }

  function saveCrop(){
    try {
      const formData = new FormData();
      formData.append("name",form.name);
      formData.append("image",form.image, form.image.name);
      formData.append("soilId",queryParam.get("id"));
      axios
      .post("http://localhost:7001/crop", formData, {
        "content-type" : "multipart/form-data",
      })
      .then((d) => {
        alert(d.data.message);
        getAll();
        resetForm();
      }).catch((e) => {
      console.log("Fail to submit data!!!!!");
      });
    } catch (error) {
      console.log("Fail to submit data!!!!!");
    }
  }


  function updateCrop(){
    try {
      const formData = new FormData();
      formData.append("name",form.name);
      formData.append("image",form.image, form.image.name);
      formData.append("soilId",queryParam.get("id"));
      formData.append("id",cropId);
      axios
      .put("http://localhost:7001/crop", formData, {
        "content-type" : "multipart/form-data",
      })
      .then((d) => {
        alert(d.data.message);
        getAll();
        resetForm();
      }).catch((e) => {
      console.log("Fail to update data!!!!!");
      });
    } catch (error) {
      console.log("Fail to update data!!!!!");
    }
  }


  function getAll(){
    try {
      axios.get("http://localhost:7001/crop?soilId=" +
      queryParam.get("id")).then((d) =>{
        setCrops(d.data.cropData);
      }).catch((e) =>{
      console.log("Fail to submit data!!!!!");
      });
    } catch (error) {
      console.log("Fail to submit data!!!!!");
    }
  }


  function resetForm(){
    setForm({ name: "", image : null});
  }


  function onCropSubmit(){
    let errors= false;
    let error = { name: "", image: ""};
    if(form.name.trim().length==0){
      errors=true;
      error={...error, name : "Please enter name!!!"};
    }
    if(form.image==null){
      errors=true;
      error={...error, image : "Please select image!!!"};
    }
    if(errors) setFormError(error);
    else{
      setFormError(error);
      cropId ? updateCrop() : saveCrop();
    }
  }
  
  function deleteCrop(deleteid){
    try {
      let ans = window.confirm("Want to delete data?");
      if(!ans) return;
      axios.delete("http://localhost:7001/crop", {data: {id: deleteid}}).then
      ((d) => {alert(d.data.message);
      getAll();
      }).catch((e) => {
      console.log("Fail to submit data!!!!!");
      })
    } catch (error) {
      console.log("Fail to submit data!!!!!");
    }
  }


  function renderCrops(){
    return crops?.map((item) => {
      return (
          <tr>
            <td>
              <img src={'http://localhost:7001/' + item.image} 
              height="300" width="450"/>
            </td>
            <td>{item.name}</td>
            <td>
              <button onClick={() => {
                navigate(ROUTES.distributorAdmin.name + 
                  "?id=" + item._id +
                  "&name=" + item.name
                  );
                }}
                className='btn btn-primary'>
                  Add Distributor
                  </button>
            </td>
            <td>
            <button onClick={() => {deleteCrop(item._id)}}  className='btn btn-danger'> 
                Delete 
              </button>
            </td>
            <td>
            <button 
                onClick={()=> {setCropId(item._id);setForm({...form, name: item.name});
                }}
                className='btn btn-info'> 
                Edit 
              </button>
            </td>
          </tr>
      );
    });
  }


  return (
    <div>
      < Header/>
      <div className='row m-2 p-2'>
      <div class="card text-center mx-auto">
  <div class="card-header bg-secondary text-white">
    {cropId ? "Edit Crop" : "New Crop"}
  </div>


  <div class="card-body">
  <div className='form-group row'>
      <label className='col-sm-4'>Soil Name</label>
      <div className='col-sm-8'>
        <input type='text' className='form-control'
          value={queryParam.get("name")} disabled/>
        
      </div>
  </div>


    <div className='form-group row'>
      <label className='col-sm-4'>Crop Name</label>
      <div className='col-sm-8'>
        <input type='text' className='form-control' name='name' placeholder='Enter Name' 
        onChange={changeHandler} value={form.name} />
        <p className='text-danger'>{formError.name}</p>
      </div>
    </div>

    <div className='form-group row'>
      <label className='col-sm-4'>Crop Image</label>
      <div className='col-sm-8'>
        <input type='file' className='form-control' onChange={(e) => {
          let file = e.target.files[0];
          setForm({ ...form, image: file});
          }} />
        <p className='text-danger'>{formError.image}</p>
      </div>
    </div>
  </div>
  <div class="card-footer text-muted bg-secondary">
    <button className='btn btn-info' onClick={() => {onCropSubmit();}} > 
      {cropId ? "Update" : "Save"} </button>
  </div>
</div>
      </div>

      <div className='border p-3 m-3'>
        <table className='table table-striped table-bordered table-hover'>
          <thead>
            <tr>
              <th>
                Image
              </th>
              <th>
                Name
              </th>
              <th>
                Add Distributor
              </th>
              <th>
                Delete 
              </th>
              <th>
                Edit
              </th>
            </tr>
          </thead>
          <tbody>{renderCrops()}</tbody>
        </table>
      </div>
      </div>
  );
}

export default Crop;
