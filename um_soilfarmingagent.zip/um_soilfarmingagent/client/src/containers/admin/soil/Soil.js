import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import ROUTES from '../../../navigations/Routes';

function Soil() {
  const [form,setForm] = useState({name:"",image: null});
  const [formError,setFormError] = useState({name:"",image:""});
  const [soilId, setSoilId] = useState(null);
  const [soils, setSoils] = useState(null);
  const navigate = useNavigate();

  useEffect(() =>{
    GetAll();
  },[]);

  const changeHandler = (e) => {
  setForm({ ...form, [e.target.name]: e.target.value});
};

  function GetAll(){
  axios.get("http://localhost:7001/soil").then((d) => {
    setSoils(d.data.soilData);
  });
}

  function ResetForm(){
  setForm({name:"", image: null});
}

  function SaveSoil()
{
  try {
    const formData = new FormData();
    formData.append("name", form.name);
    formData.append("image", form.image, form.image.name);
    axios.post("http://localhost:7001/soil", formData, {
      "content-type": "multipart/form-data",
    }).then((d) => {
      alert(d.data.message);
      GetAll();
      ResetForm();
    });
  } catch (error) {
    console.log("Fail to submit data!!!");
  }
  // axios.post("http://localhost:7001/soil",form)
}
  
  function UpdateSoil()
{
  try {
    const formData = new FormData();
    formData.append("name", form.name);
    formData.append("image", form.image, form.image.name);
    formData.append("id", soilId);

    axios.put("http://localhost:7001/soil", formData, {
      "content-type": "multipart/form-data",
    }).then((d) => {
      alert(d.data.message);
      GetAll();
      ResetForm();
    });
  } catch (error) {
    console.log("Fail to submit data!!!");
  }
  // axios.post("http://localhost:7001/soil",form)
}


  function DeleteSoil(id){
    try {
      let ans = window.confirm("Want to delete data?");
      if (!ans) return;
      axios.delete("http://localhost:7001/soil", {data:{id:id}})
      .then((d) => {alert(d.data.message);
        GetAll();
      });
    } catch (error) {
    console.log("Fail to delete data!!!");
    }
  }

  function OnSoilSubmit(){
  let errors = false;
  let error = {name:"", image:""};
  if(form.name.trim().length ==0) {
    errors = true;
    error = {...error, name: "Soil Name Empty!!!"};
  }
  if(form.image == null){
    errors = true;
    error = {...error, name: "Please select image!!!"};
  }
  if(errors){
    setFormError(error);
  }else {
      setFormError(error);
      {
        soilId ? UpdateSoil() : SaveSoil();
      }
    }
  }


  function RenderSoils(){
    return soils ?.map((item) =>{
      return(
        <tr>
          <td>
            <img src={"http://localhost:7001/" + item.image}
            height="300"
            width="450" />
          </td>
          <td>
            {item.name}
          </td>
          <td>
            <button className='btn btn-success' onClick={() =>{navigate(
              ROUTES.cropAdmin.name +"?id=" + item._id + "&name=" + item.name);
            }} >Add Crop</button>
          </td>
          <td>
            <button onClick={() => {DeleteSoil(item._id);}} 
            className='btn btn-danger'>Delete</button>
          </td>
          <td>
            <button className='btn btn-info' onClick={() => {
              setSoilId(item._id);
              setForm({ ...form, name: item.name});
            }} >Edit</button>
          </td>
        </tr>
      )
    })
  }


  return (
    <div>
      <Header />
      <div className='row m-2 p-2'>
        <div class="card text-center mx-auto">
          <div class="card-header bg-secondary text-white">
            {soilId ? "Edit Soil" : "New Soil"}
  </div>
  <div class="card-body">
    <div className='form-group row'>
    <label className='col-lg-4'>Soil Name</label>
    <div className='col-lg-8'>
    <input type='text' name='name' placeholder='Enter Name' 
    className='form-control' onChange={changeHandler} value={form.name} />
    <p className='text-danger'> {formError.name}</p>
    </div>
    </div>
    <div className='form-group row'>
    <label className='col-lg-4'>Soil Image</label>
    <div className='col-lg-8'>
    <input type='file' className='form-control' onChange={(e) => {
      let file = e.target.files[0];
      setForm({ ...form, image: file});
    }} />
    <p className='text-danger'> {formError.image}</p>

    </div>
    </div>
  </div>
  <div class="card-footer text-muted bg-secondary">
    {soilId ? (
      <button onClick={() => {OnSoilSubmit();}} 
      className='btn btn-success'>Update</button>
    ) : (
    <button className='btn btn-outline-light bg-info text-white' 
    onClick={() => {OnSoilSubmit();}} >Save</button>
    )}
      </div>
    </div>
  </div>


  <div className='bordered'>
    <table className='table table-striped table-bordered'>
      <thead>
        <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Add Crop</th>
          <th>Delete</th>
          <th>Edit</th>
        </tr>
      </thead>
      <tbody>{RenderSoils()}</tbody>
    </table>
  </div>
</div>
  )
}

export default Soil;
