import React, { useEffect, useState } from 'react'
import Header from '../../../components/Header'
import { useLocation } from 'react-router-dom'
import axios from 'axios';

function useQuery()
{
  const {search}=useLocation();
  return React.useMemo(()=> new URLSearchParams(search), [search]);
}

function Distributor() {
  const queryParam=useQuery();
  const [distributorId, setDistributorId] = useState(null);
  const [distributors, setDistributors]=useState(null);
  const [form, setForm]=useState({
    name:"",
    images:null,
    cropId:queryParam.get("id"),
    description:"",
    qty:10,
    price:0.
  });
  const [formError, setFormError]=useState({
    name:"",
    images:null,
    description:"",
    qty:10,
    price:0.
  });

  useEffect(()=>{
    getAll();
  }, []);

  const changeHandler=(e)=>{
    setForm({...form, [e.target.name]:e.target.value});
  };
  function getAll()
  {
    try {
      axios
      .get("http://localhost:7001/distributor?cropId=" + queryParam.get("id"))
      .then((d)=>{
        setDistributors(d.data.distributorData);
      });
    } catch (error) {
      console.log("Fail to submit data!!!");
    }
  }

  function saveDistributor()
  {
    try {
      const formData = new FormData();
      for(let i=0; i<form.images.length; i++)
      {
        formData.append("images", form.images[i], form.images[i].name);
      }
      formData.append("name", form.name);
      formData.append("description", form.description);
      formData.append("price", form.price);
      formData.append("qty", form.qty);
      formData.append("cropId", queryParam.get("id"));
axios
.post("http://localhost:7001/distributor", formData, {
  "content-type":"multipart/form-data",
})
.then((d)=>{
  alert(d.data.message);
  getAll();
  //resetForm();
})
.then((e)=>{
  console.log("Fail to submit data!!!");
})
  } catch (error) {
      console.log("Fail to submit data!!!");
    }
  }

  function updateDistributor()
  {
    try {
      const formData = new FormData();
      for(let i=0; i<form.images.length; i++)
      {
        formData.append("images", form.images[i], form.images[i].name);
      }
      formData.append("name", form.name);
      formData.append("description", form.description);
      formData.append("price", form.price);
      formData.append("qty", form.qty);
      formData.append("cropId", queryParam.get("id"));
      formData.append("id", distributorId);
axios
.put("http://localhost:7001/distributor", formData, {
  "content-type":"multipart/form-data",
})
.then((d)=>{
  alert(d.data.message);
  getAll();
  resetForm();
})
.then((e)=>{
  console.log("Fail to submit data!!!");
})
  } catch (error) {
      console.log("Fail to submit data!!!");
    }
  }
  function resetForm()
  {
    setForm({name:"", images:null, description:"", qty:10, price:0});
  }

function onDistributorSubmit()
{
  let errors = false;
  let error={name:"", images:"",
    description:"", qty:"", price:""};
if(form.name.trim().length==0){
  errors=true;
  error={...error, name:"distibutor's enter name"};
}
if(form.description.length==0){
  errors=true;
  error={...error, description:"distibutor's enter description !!!"};
}
if(form.qty=="" || form.qty==0){
  errors=true;
  error={...error, qty:"distibutor's enter Qty. !!!"};
}
if(form.price=="" || form.price==0){
  errors=true;
  error={...error, price:"distibutor's enter price !!!"};
}
if(form.images == null){
  errors=true;
  error={...error, images:"distibutor's select image !!"};
}
if(errors) setFormError(error);
else{
  setFormError(error);
  {
    distributorId ? updateDistributor():saveDistributor();
  }
}
}

function renderDistributors()
{
  return distributors?.map((item) => {
    return(
      <tr>
        <td>
          <img src={"http://localhost:7001/" + item.images[0]}
          height='200'
          width='200'
          />
        </td>
        <td>{item.name}</td>
        <td>{item.description}</td>
        <td>{item.price}</td>
        <td>{item.qty}</td>
        <td>
          <button className='btn btn-danger'
          onClick={() =>{ deleteDistributor(item._id);}}
          >
          Delete
          </button>
        </td>
        <td>
          <button className='btn btn-info' onClick={()=>{setDistributorId(item._id);
          setForm({...form,
            name: item.name,
            description: item.description,
            qty: item.qty,
            price: item.price,
          });
          }}>
          Edit
          </button>
        </td>
      </tr>
    )
  })
}

function deleteDistributor(id) {
  let ans = window.confirm("Are you sure you want to delete data??");
  if(!ans) return;
  try {
    axios.delete("http://localhost:7001/distributor", {data : {id:id}}).then((d) => {
      alert(d.data.message);
      getAll();
    });
  } catch (error) {
    console.log("Fail to submit data!!!");
  }
}

  return (
    <div>
      <Header/>
      <div className='row p-2 m-2'>
      <div class="card text-center mx-auto">
  <div class="card-header bg-info text-white">
    {distributorId? "Edit Distributor" : "New Distributor"}
  </div>
  <div class="card-body">
   <div className='form-group row'>
    <label className='col-4 '>Crop Name</label>
    <div className='col-8'>
      <input type='text' value={queryParam.get("name")} disabled className='form-control'/>
    </div>
   </div>

   <div className='form-group row'>
    <label className='col-4 '>Distributor Name</label>
    <div className='col-8'>
      <input type='text'
      value={form.name}
      className='form-control'
      name='name'
      onChange={changeHandler}
      placeholder='Enter name here'/>
      <p className='text-danger'>{formError.name}</p>

    </div>
   </div>

   <div className='form-group row'>
    <label className='col-4'>Distributor Description</label>
    <div className='col-8'>
      <input type='text' value={form.description} className='form-control' name='description'
       onChange={changeHandler}
      placeholder=' Distributor Description'/>
      <p className='text-danger'>{formError.description}</p>
    </div>
   </div>

   <div className='form-group row'>
    <label className='col-4'>Distributor Price</label>
    <div className='col-8'>
      <input type='number' value={form.price} className='form-control' name='price' onChange={changeHandler}
      placeholder='Price'/>
    
    </div>
   </div>

   <div className='form-group row'>
    <label className='col-4'>Quantity</label>
    <div className='col-8'>
      <input type='number' value={form.qty} className='form-control' name='qty' onChange={changeHandler}
      placeholder='Qty'/>

    </div>
   </div>

   <div className='form-group row'>
    <label className='col-4'>Image</label>
    <div className='col-8'>
      <input type='file' className='form-control' onChange={(e)=>{let files=e.target.files;
      setForm({...form,images:files});
    }}
      multiple
      />
      <p className='text-danger'>{formError.images}</p>

    </div>
   </div>

  </div>
  <div class="card-footer text-muted">
    <button onClick={()=>{onDistributorSubmit()}} className='btn btn-info'>
      {distributorId ? "Update" : "Save"}
    </button>
    </div>
  </div>
</div>


<div className='border p-2 m-2'>
        <table className='table table-bordered table-striped table-hover'>
        <thead>
          <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Delete</th>
            <th>Edit</th>
          </tr>
        </thead>
        <tbody>
          {renderDistributors()}
        </tbody>
        </table>
  </div>
</div>
  );
}

export default Distributor;
