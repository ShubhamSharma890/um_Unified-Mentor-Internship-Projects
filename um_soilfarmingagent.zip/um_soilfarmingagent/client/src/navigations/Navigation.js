import React from 'react'
import {BrowserRouter, Route, Routes} from "react-router-dom";
import ROUTES from "./Routes";

function Navigation() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path={ROUTES.about.name} element={ROUTES.about.component} />
        <Route path={ROUTES.contact.name} element={ROUTES.contact.component} />
        <Route path={ROUTES.support.name} element={ROUTES.support.component} />
        <Route path={ROUTES.login.name} element={ROUTES.login.component} />
        <Route path={ROUTES.register.name} element={ROUTES.register.component} />
        <Route path={ROUTES.soilAdmin.name} element={ROUTES.soilAdmin.component} />
        <Route path={ROUTES.cropAdmin.name} element={ROUTES.cropAdmin.component} />
        <Route path={ROUTES.distributorAdmin.name} element={ROUTES.distributorAdmin.component} />
        <Route path={ROUTES.home.name} element={ROUTES.home.component} />
        <Route path={ROUTES.crop.name} element={ROUTES.crop.component} />
        <Route path={ROUTES.distributor.name} element={ROUTES.distributor.component} />
        <Route
          path={ROUTES.distributorDetail.name}
          element={ROUTES.distributorDetail.component} />
      </Routes>
      
      </BrowserRouter>
    </div>
  )
}

export default Navigation
