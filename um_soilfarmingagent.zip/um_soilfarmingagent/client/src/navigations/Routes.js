import React from 'react'
import Contact from '../containers/contact/Contact';
import Support from '../containers/support/Support';
import Login from '../containers/login/Login';
import Register from '../containers/register/Register';
import Soil from '../containers/admin/soil/Soil';
import Distributor from '../containers/admin/distributor/Distributor';
import Home from '../containers/user/home/Home';
import UserDistributor from '../containers/user/distributor/UserDistributor';
import About from '../containers/about/About';
import DistributorDetail from '../containers/user/distributorDetail/DistributorDetail';
import Crop from '../containers/admin/crop/Crop';
import UserCrop from '../containers/user/crop/UserCrop';


const ROUTES = {
  contact: {
    name: "/contact",
    component: <Contact/>,
  },
  about: {
    name: "/about",
    component: <About/>,
  },
  support: {
    name: "/support",
    component: <Support/>,
  },
  login: {
    name: "/login",
    component: <Login/>,
  },
  register: {
    name: "/register",
    component: <Register/>,
  },
  soilAdmin: {
    name: "/soilAdmin",
    component: <Soil/>,
  },
  cropAdmin: {
    name: "/cropAdmin",
    component: <Crop/>,
  },
  distributorAdmin: {
    name: "/distributorAdmin",
    component: <Distributor/>,
  },
  home: {
    name: "/",
    component: <Home/>,
  },
  crop: {
    name: "/crop",
    component: <UserCrop/>,
  },
  distributor: {
    name: "/distributor",
    component: <UserDistributor/>,
  },
  distributorDetail:{
    name:"/distributorDetail",
    component: <DistributorDetail/>
  },
};
export default ROUTES;
