import React, { useState } from "react";
import Switch from "../components/Switch";
import Calculator from "../components/Calculator";
import History from "../components/History";

const Home = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);

  const handleChange = (index) => {
    setSelectedIndex(index);
  };

  return (
    <div className="flex items-center justify-center">
      <div className="border bg-gray-700 p-2 h-[650px] w-[400px]">
        <div className="px-1 py-1">
          <Switch
            options={["calculator", "calculations"]}
            selectedIndex={selectedIndex}
            onClick={handleChange}
          />
        </div>
        {selectedIndex === 0 ? <Calculator /> : <History />}
      </div>
    </div>
  );
};
export default Home;
