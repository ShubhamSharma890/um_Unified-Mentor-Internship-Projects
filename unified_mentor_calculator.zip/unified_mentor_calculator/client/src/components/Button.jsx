import React from "react";

const Button = React.forwardRef(({ children, className, dataid, onClick }, ref) => {
  return (
    <button
      className="flex h-[70px]  items-center justify-center bg-dark-100
         text-white hover:bg-orange-500 hover:text-black "
      onClick={onClick}
      ref={ref}
      data-testid={dataid}
    >
      {children}
    </button>
  );
});

export default Button;
