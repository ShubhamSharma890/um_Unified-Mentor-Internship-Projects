import React, { useEffect, useState } from "react";
import { getAllHistory } from "./helper/apiHelper";
import Spinner from "./Spinner";
import ShowHistory from "./ShowHistory";

const History = () => {
  const [histories, setHistories] = useState([]);
  const [loading, setLoading] = useState([]);

  useEffect(() => {
    setLoading(true);
    async function fetchData() {
      try {
        const response = await getAllHistory();
        setHistories(response);
        setLoading(false);
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data: ", error.message);
      }
    }
    fetchData();
  }, []);

  return (
    <div className="w-full">
      <div className="m-auto mb-4 w-max">
        <ul className="overflow-y-auto  max-h-[550px]">
          {loading ? (
            <Spinner />
          ) : (
            histories.map((history, idx) => (
              <ShowHistory key={idx} history={history} />
            ))
          )}
        </ul>
        
      </div>
    </div>
  );
};

export default History;
