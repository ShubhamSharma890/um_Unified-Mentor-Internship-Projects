import React from "react";

const Switch = (props) => {
  const { options, selectedIndex, onClick } = props;

  return (
    <div className="h-10 rounded overflow-hidden">
      <div className="relative flex h-full">
        {options.map((option, index) => (
          <div
            key={index}
            className={`flex-1 flex items-center justify-center text-white
              ${index === selectedIndex ? "bg-blue-500 text-white-900" : "bg-orange-200 text-black-800"}`}
            onClick={() => onClick(index)}
          >
            <span className="text-l capitalize">{option}</span>
          </div>
        ))}
        <div
          className="absolute top-0 h-full bg-white-300"
          style={{
            width: `${100 / options.length}%`,
            left: `${(100 / options.length) * selectedIndex}%`,
          }}
        ></div>
      </div>
    </div>
  );
};

export default Switch;
