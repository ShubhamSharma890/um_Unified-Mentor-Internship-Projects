import React from "react";

const ShowHistory = ({ history }) => {
  return (
    <li>
      <div className="">
        <div className="flex items-center justify-between">
          <h3 className="text-l text-white">
            {history.expression}
          </h3>
          <p className="text-l text-white">
            ={history.result}
          </p>
        </div>
        <div className="">
          <p className="text-l font-medium text-gray-100">
            date:{" "}
            <span className="text-xl text-orange-400">
              {new Date(history.createdAt).toLocaleString()}
            </span>
          </p>
        </div>
      </div>
    </li>
  );
};

export default ShowHistory;
