import React from "react";

const Spinner = () => {
  return (
    <div className="text-white">Wait a sec please!!....</div>
  );
};

export default Spinner;
