/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // primary: "orange-peel",
        // secondary: "midnight-express",
        // dark: {
        //   100: "midnight-express",
        //   200: "fire-engine-red",
        //   300: "north-sea-blue",
        // },
        // background: "blue",
        // text: "white",
        // light: {
        //   100: "very-dark-grayish-yellow",
        //   200: "jet",
        //   300: "davy's-grey",
        // },
        // backgroundDark: "black",
        // textDark: "white",
      },
    },
  },
  plugins: [],
  darkMode: "class",
};
