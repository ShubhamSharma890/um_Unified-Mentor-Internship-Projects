# Getting Started
change directory by writing command ,cd server, in the terminal,then run npm install to instal node package modules.
after installing, run, npm start.
change directory to client, cd client, run npm install again. Wait for installation and then run,npm start to run this Web Application.
